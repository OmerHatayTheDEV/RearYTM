package dev.ytrear.app

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import androidx.core.app.NotificationManagerCompat
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

/**
 * Optional Shizuku bridge. Everything here is best-effort: with Shizuku the app configures itself
 * (notification access, background limits), repairs a dropped listener and can truly unsnooze a
 * notification. Without Shizuku the app behaves exactly as before.
 */
object Sh {
    private const val REQUEST_CODE = 4242
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun available(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun granted(): Boolean = available() && try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun requestPermission(onResult: (Boolean) -> Unit) {
        if (!available()) { onResult(false); return }
        if (granted()) { onResult(true); return }
        val listener = object : Shizuku.OnRequestPermissionResultListener {
            override fun onRequestPermissionResult(requestCode: Int, grantResult: Int) {
                if (requestCode != REQUEST_CODE) return
                Shizuku.removeRequestPermissionResultListener(this)
                main.post { onResult(grantResult == PackageManager.PERMISSION_GRANTED) }
            }
        }
        Shizuku.addRequestPermissionResultListener(listener)
        Shizuku.requestPermission(REQUEST_CODE)
    }

    /** Runs blocking Shizuku work off the main thread. */
    fun async(block: () -> Unit) {
        io.execute {
            try { block() } catch (e: Throwable) {
                Probe.log("SHIZUKU: ${e.javaClass.simpleName}: ${e.message}")
            }
        }
    }

    /** Shizuku 13 made newProcess private; call it reflectively. stderr is merged into stdout. */
    fun exec(cmd: String): String {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", "($cmd) 2>&1"), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        return out.trim()
    }

    private fun quote(s: String) = "'" + s.replace("'", "'\\''") + "'"

    private fun component(c: Context) =
        ComponentName(c, MediaNotificationListener::class.java).flattenToString()

    fun listenerEnabled(c: Context): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)

    /** One-tap setup: notification access, "restricted settings" lift, background allowance. */
    fun setup(c: Context): String {
        val pkg = c.packageName
        val out = exec(
            listOf(
                "appops set $pkg ACCESS_RESTRICTED_SETTINGS allow",
                "cmd notification allow_listener ${component(c)}",
                "dumpsys deviceidle whitelist +$pkg",
                "cmd appops set $pkg RUN_IN_BACKGROUND allow",
                "cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow"
            ).joinToString("; ")
        )
        Probe.log("SHIZUKU: setup -> ${out.take(200).ifBlank { "ok" }}")
        NotificationListenerService.requestRebind(ComponentName(c, MediaNotificationListener::class.java))
        return out
    }

    /** Re-enables the listener if HyperOS dropped it; toggles it to force a rebind if unbound. */
    fun ensureListener(c: Context) {
        if (!granted()) return
        val comp = component(c)
        if (!listenerEnabled(c)) {
            exec("cmd notification allow_listener $comp")
            Probe.log("SHIZUKU: listener was disabled; re-enabled")
        } else if (!MediaNotificationListener.isConnected) {
            exec("cmd notification disallow_listener $comp; cmd notification allow_listener $comp")
            Probe.log("SHIZUKU: listener was unbound; forced a rebind")
        }
        NotificationListenerService.requestRebind(ComponentName(c, MediaNotificationListener::class.java))
    }

    /** Truly unsnoozes one notification. Returns false if the shell command is not supported. */
    fun unsnooze(key: String): Boolean {
        val out = exec("cmd notification unsnooze ${quote(key)}")
        val bad = out.contains("unknown", true) || out.contains("usage", true) ||
            out.contains("exception", true) || out.contains("error", true)
        Probe.log("SHIZUKU: unsnooze -> ${if (bad) out.take(120) else "ok"}")
        return !bad
    }
}
