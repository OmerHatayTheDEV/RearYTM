package dev.ytrear.app

import android.content.Context
import androidx.core.content.edit

/** Small persisted switches shared by the UI, the listener and the controller. */
object AppSettings {
    private const val PREFS = "app_settings"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_HIDE_TARGET = "hide_target"

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Master switch: when off, no proxy is published and nothing is snoozed. */
    fun enabled(c: Context) = p(c).getBoolean(KEY_ENABLED, true)
    fun setEnabled(c: Context, v: Boolean) = p(c).edit { putBoolean(KEY_ENABLED, v) }

    /** Snooze the selected player's own media notification (Dynamic Island fix). */
    fun hideTarget(c: Context) = p(c).getBoolean(KEY_HIDE_TARGET, true)
    fun setHideTarget(c: Context, v: Boolean) = p(c).edit { putBoolean(KEY_HIDE_TARGET, v) }
}
