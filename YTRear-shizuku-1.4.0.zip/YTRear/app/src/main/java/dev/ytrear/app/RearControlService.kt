package dev.ytrear.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/**
 * Keeps the allowlisted proxy MediaSession alive while the selected player is active.
 */
class RearControlService : Service() {

    private var observing = false
    private val handler = Handler(Looper.getMainLooper())

    /** With Shizuku, repairs a notification listener that HyperOS dropped or refused to rebind. */
    private val watchdog = object : Runnable {
        override fun run() {
            if (Sh.granted() && AppSettings.enabled(this@RearControlService)) {
                val app = applicationContext
                Sh.async { Sh.ensureListener(app) }
            }
            handler.postDelayed(this, WATCHDOG_MS)
        }
    }

    private val mediaListener = MediaHub.Listener { state ->
        RearController.render(this, state)
    }

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        startForeground(NOTIF_ID, foregroundNotification())
        beginObserving()
        handler.postDelayed(watchdog, WATCHDOG_FIRST_MS)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, foregroundNotification())
        beginObserving()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun beginObserving() {
        val attached = MediaHub.attach(this)
        if (!observing) {
            MediaHub.addListener(mediaListener)
            observing = true
        }
        Probe.log("CONTROL SERVICE: active; session access=$attached")
    }

    override fun onDestroy() {
        handler.removeCallbacks(watchdog)
        if (observing) {
            MediaHub.removeListener(mediaListener)
            observing = false
        }
        isRunning = false
        if (!MediaNotificationListener.isConnected) {
            NativeMediaProxy.clear(this)
            MediaHub.detach()
        }
        super.onDestroy()
    }

    private fun foregroundNotification(): Notification {
        val manager = getSystemService(NotificationManager::class.java)
        if (manager.getNotificationChannel(CHANNEL) == null) {
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL,
                    "Rear controls service",
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        }
        val open = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle(
                "${PlayerSelection.selectedLabel(this) ?: "Selected player"} rear controller"
            )
            .setContentText("Allowlisted media proxy is active")
            .setContentIntent(open)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    companion object {
        private const val CHANNEL = "rear_control_service"
        private const val NOTIF_ID = 76
        private const val WATCHDOG_FIRST_MS = 15_000L
        private const val WATCHDOG_MS = 30_000L

        @Volatile
        var isRunning = false
            private set

        fun stop(context: Context) {
            context.stopService(Intent(context, RearControlService::class.java))
        }

        fun start(context: Context) {
            context.startForegroundService(Intent(context, RearControlService::class.java))
        }
    }
}
