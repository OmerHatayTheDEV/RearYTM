package dev.ytrear.app

import android.app.Notification
import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Holding notification-listener access unlocks MediaSessionManager.getActiveSessions(). Updates
 * from the selected player's MediaStyle notification also trigger the proxy's ranking defence.
 * The selected player's original media notification is snoozed while YTRear supplies its proxy,
 * preventing the original card from taking back HyperOS's top-media rank during track changes.
 */
class MediaNotificationListener : NotificationListenerService() {

    private var observing = false
    private val mediaListener = MediaHub.Listener { state ->
        RearController.render(this, state)
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        activeInstance = this
        isConnected = true
        val attached = MediaHub.attach(this)
        if (!observing) {
            MediaHub.addListener(mediaListener)
            observing = true
        }
        restorePreviousPlayerMediaNotifications()
        if (shouldHide()) snoozeActiveTargetMediaNotification() else restoreSelectedPlayerNow()
        Probe.log("MEDIA LISTENER: connected; session access=$attached")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        val target = MediaHub.targetPackage ?: PlayerSelection.selectedPackage(this)
        if (target == null || sbn?.packageName != target) return
        if (!sbn.notification.extras.containsKey(Notification.EXTRA_MEDIA_SESSION)) return

        if (!AppSettings.enabled(this)) return
        RearController.onTargetMediaNotification(this)
        if (shouldHide()) snoozeTargetMediaNotification(sbn)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
        if (sbn?.packageName == packageName && sbn.id == NativeMediaProxy.NOTIF_ID) {
            NativeMediaProxy.onNotificationRemoved()
        }
    }

    override fun onListenerDisconnected() {
        stopObserving()
        super.onListenerDisconnected()
        NotificationListenerService.requestRebind(
            ComponentName(this, MediaNotificationListener::class.java)
        )
    }

    override fun onDestroy() {
        stopObserving()
        super.onDestroy()
    }

    private fun stopObserving() {
        if (activeInstance === this) activeInstance = null
        isConnected = false
        if (observing) {
            MediaHub.removeListener(mediaListener)
            observing = false
        }
        if (!RearControlService.isRunning) {
            NativeMediaProxy.clear(this)
            MediaHub.detach()
        }
    }

    private fun snoozeActiveTargetMediaNotification() {
        val target = MediaHub.targetPackage ?: PlayerSelection.selectedPackage(this) ?: return
        val active = try {
            activeNotifications.orEmpty()
        } catch (e: SecurityException) {
            Probe.log("MEDIA LISTENER: cannot inspect active notifications (${e.javaClass.simpleName})")
            return
        }
        active.firstOrNull {
            it.packageName == target &&
                it.notification.extras.containsKey(Notification.EXTRA_MEDIA_SESSION)
        }?.let(::snoozeTargetMediaNotification)
    }

    private fun shouldHide() = AppSettings.enabled(this) && AppSettings.hideTarget(this)

    /**
     * Releases snoozed media notifications of [packages]. With Shizuku the notification is truly
     * unsnoozed through the shell; otherwise (or if the shell command fails) the existing snooze
     * is shortened to a near-immediate deadline so Android reposts it normally.
     * Returns the packages that were handled.
     */
    private fun releaseSnoozed(packages: Set<String>): Set<String> {
        if (packages.isEmpty()) return emptySet()
        val snoozed = try {
            snoozedNotifications.orEmpty()
        } catch (e: SecurityException) {
            Probe.log("MEDIA LISTENER: cannot inspect snoozed notifications (${e.javaClass.simpleName})")
            return emptySet()
        }
        val media = snoozed.filter {
            it.packageName in packages && it.notification.extras.containsKey(Notification.EXTRA_MEDIA_SESSION)
        }
        val handled = packages.filter { pkg -> media.none { it.packageName == pkg } }.toMutableSet()
        media.forEach { sbn ->
            try {
                if (Sh.granted()) {
                    Sh.async { if (!Sh.unsnooze(sbn.key)) shortenSnooze(sbn.key) }
                } else {
                    shortenSnooze(sbn.key)
                }
                handled += sbn.packageName
                Probe.log("MEDIA LISTENER: restoring media notification (${sbn.packageName})")
            } catch (e: SecurityException) {
                Probe.log("MEDIA LISTENER: notification restore failed (${e.javaClass.simpleName})")
            }
        }
        return handled
    }

    private fun shortenSnooze(key: String) {
        try { snoozeNotification(key, RESTORE_MEDIA_DELAY_MS) } catch (e: SecurityException) {
            Probe.log("MEDIA LISTENER: notification restore failed (${e.javaClass.simpleName})")
        }
    }

    private fun restorePreviousPlayerMediaNotifications() {
        val pending = PlayerSelection.pendingRestorePackages(this)
        if (pending.isEmpty()) return
        PlayerSelection.markRestoresHandled(this, releaseSnoozed(pending))
    }

    private fun restoreSelectedPlayerNow() {
        val target = MediaHub.targetPackage ?: PlayerSelection.selectedPackage(this) ?: return
        releaseSnoozed(setOf(target))
    }

    private fun snoozeTargetMediaNotification(sbn: StatusBarNotification) {
        try {
            snoozeNotification(sbn.key, TARGET_MEDIA_SNOOZE_MS)
            Probe.log(
                "MEDIA LISTENER: snoozed selected player media notification for 30 days " +
                    "(${sbn.packageName})"
            )
        } catch (e: SecurityException) {
            Probe.log("MEDIA LISTENER: notification snooze failed (${e.javaClass.simpleName})")
        }
    }

    companion object {
        private const val TARGET_MEDIA_SNOOZE_MS = 30L * 24L * 60L * 60L * 1000L
        private const val RESTORE_MEDIA_DELAY_MS = 250L

        @Volatile
        private var activeInstance: MediaNotificationListener? = null

        @Volatile
        var isConnected = false
            private set

        /** Gives the selected player's snoozed media notification back right now. */
        fun restoreNow(context: android.content.Context) {
            val listener = activeInstance
            if (listener != null) listener.restoreSelectedPlayerNow()
            else Probe.log("MEDIA LISTENER: not connected; notification returns when the player next posts")
        }

        /** Applies the new selection immediately when the listener is already connected. */
        fun targetChanged(context: android.content.Context) {
            val listener = activeInstance
            if (listener != null) {
                listener.restorePreviousPlayerMediaNotifications()
                if (listener.shouldHide()) {
                    listener.snoozeActiveTargetMediaNotification()
                } else {
                    listener.restoreSelectedPlayerNow()
                }
            } else {
                NotificationListenerService.requestRebind(
                    ComponentName(context, MediaNotificationListener::class.java)
                )
            }
        }
    }
}
