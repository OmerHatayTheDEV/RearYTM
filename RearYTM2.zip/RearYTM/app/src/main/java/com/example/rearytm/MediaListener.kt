package com.example.rearytm

import android.content.ComponentName
import android.content.Context
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService

class MediaListener : NotificationListenerService()

object Media {
    const val YTM = "com.google.android.apps.youtube.music"
    private fun prefs(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    fun selected(c: Context): Set<String> = prefs(c).getStringSet("pkgs", setOf(YTM, "com.google.android.youtube"))!!
    fun save(c: Context, s: Set<String>) = prefs(c).edit().putStringSet("pkgs", s).apply()
    fun stopXiaomi(c: Context) = prefs(c).getBoolean("stopx", true)
    fun setStopXiaomi(c: Context, v: Boolean) = prefs(c).edit().putBoolean("stopx", v).apply()

    fun sessions(c: Context): List<MediaController> = try {
        val sel = selected(c)
        c.getSystemService(MediaSessionManager::class.java)
            .getActiveSessions(ComponentName(c, MediaListener::class.java))
            .filter { it.packageName in sel }
    } catch (e: SecurityException) { emptyList() }

    // Beğeni: uygulamanın medya oturumunda açtığı özel eylem (YT Music gibi) aranır.
    private val LIKE = Regex("like|thumb|heart|favou?rite|beğen|begen", RegexOption.IGNORE_CASE)
    private val BAD = Regex("dislike|thumbs?_?down|beğenme|begenme", RegexOption.IGNORE_CASE)
    val UNLIKE = Regex("unlike|un_like|remove|undo|\\bliked\\b", RegexOption.IGNORE_CASE)
    fun txt(a: PlaybackState.CustomAction) = "${a.action} ${a.name}"
    fun likeAction(s: PlaybackState?): PlaybackState.CustomAction? =
        s?.customActions?.firstOrNull { LIKE.containsMatchIn(txt(it)) && !BAD.containsMatchIn(txt(it)) }
}
