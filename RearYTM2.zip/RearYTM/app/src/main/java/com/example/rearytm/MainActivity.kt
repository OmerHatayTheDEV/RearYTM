package com.example.rearytm

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.view.Display
import android.view.ViewGroup
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var status: TextView
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val bg = 0xFF07080D.toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(56), dp(22), dp(24)); setBackgroundColor(bg) }
        fun txt(s: String, sz: Float, col: Int) = TextView(this).apply { text = s; textSize = sz; setTextColor(col) }.also { root.addView(it) }
        txt("Rear Beam", 30f, Color.WHITE)
        txt("Arka ekran medya kumandası", 14f, 0xFF8A8FA8.toInt())
        status = txt("", 13f, 0xFFB8BCD0.toInt()).apply { setPadding(0, dp(16), 0, dp(8)) }
        btn(root, "1 · Kurulum — Shizuku ile yetki ver", true) { shizukuSetup() }
        btn(root, "2 · Uygulamaları seç", false) { pickApps() }
        btn(root, "3 · Arka ekranda başlat", true) { startRear() }
        btn(root, "Arka ekranı kapat", false) { RearActivity.inst?.finish() }
        btn(root, "Ön ekranda önizle", false) { startActivity(Intent(this, RearActivity::class.java)) }
        root.addView(CheckBox(this).apply {
            text = "Xiaomi arka ekran uygulamasını durdur (ekranı geri almasın)"
            setTextColor(0xFFB8BCD0.toInt()); isChecked = Media.stopXiaomi(this@MainActivity)
            setOnCheckedChangeListener { _, c -> Media.setStopXiaomi(this@MainActivity, c) }
        })
        setContentView(ScrollView(this).apply { setBackgroundColor(bg); addView(root) })
    }

    private fun btn(root: LinearLayout, t: String, primary: Boolean, a: () -> Unit) {
        root.addView(Button(this).apply {
            text = t; isAllCaps = false; setTextColor(Color.WHITE); textSize = 15f
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                if (primary) { colors = intArrayOf(0xFF7C5CFF.toInt(), 0xFF22D3EE.toInt()); orientation = GradientDrawable.Orientation.LEFT_RIGHT }
                else { setColor(0xFF161827.toInt()); setStroke(dp(1), 0x33FFFFFF) }
            }
            setOnClickListener { a() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)).apply { topMargin = dp(10) })
    }

    private fun listenerOn() = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")?.contains(packageName) == true

    override fun onResume() {
        super.onResume()
        val sh = when { Sh.granted() -> "yetkili ✓"; Sh.available() -> "çalışıyor, izin gerekli"; else -> "kapalı / başlatılmamış" }
        status.text = "Shizuku: $sh\nBildirim erişimi: ${if (listenerOn()) "açık ✓" else "kapalı ✗"}\n" +
            "Seçili uygulama: ${Media.selected(this).size}   ·   Aktif oturum: ${Media.sessions(this).size}"
    }

    private fun shizukuSetup() {
        if (!Sh.available()) { toast("Önce Shizuku'yu başlat"); return }
        if (Sh.granted()) { runSetup(); return }
        Shizuku.addRequestPermissionResultListener(object : Shizuku.OnRequestPermissionResultListener {
            override fun onRequestPermissionResult(code: Int, result: Int) {
                Shizuku.removeRequestPermissionResultListener(this)
                if (result == 0) runSetup() else toast("İzin reddedildi")
            }
        })
        Shizuku.requestPermission(Sh.CODE)
    }

    private fun runSetup() = Thread {
        val r = try { Sh.setup() } catch (e: Throwable) { "Hata: ${e.message}" }
        runOnUiThread {
            try { NotificationListenerService.requestRebind(ComponentName(this, MediaListener::class.java)) } catch (e: Throwable) {}
            onResume()
            toast(if (listenerOn()) "Bildirim erişimi açıldı ✓" else "Açılamadı. Çıktı: ${r.take(160)}")
        }
    }.start()

    private fun pickApps() {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }.sortedBy { it.second.lowercase() }
        val sel = Media.selected(this)
        val checked = BooleanArray(apps.size) { apps[it].first in sel }
        AlertDialog.Builder(this).setTitle("Uygulamaları seç")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Kaydet") { _, _ ->
                Media.save(this, apps.indices.filter { checked[it] }.map { apps[it].first }.toSet()); onResume()
            }.setNegativeButton("İptal", null).show()
    }

    private fun startRear() {
        if (!Sh.granted()) { toast("Önce Shizuku yetkisi ver (1. buton)"); return }
        val id = getSystemService(DisplayManager::class.java).displays.firstOrNull { it.displayId != Display.DEFAULT_DISPLAY }?.displayId ?: 1
        val stop = Media.stopXiaomi(this)
        Thread {
            val r = try { Sh.exec("am start --display $id -n ${Sh.PKG}/.RearActivity") } catch (e: Throwable) { "error ${e.message}" }
            if (Regex("error|exception|102|denied|not exist", RegexOption.IGNORE_CASE).containsMatchIn(r)) {
                // HyperOS doğrudan açılışı engelledi → ön ekranda aç, sonra arka ekrana taşı.
                runOnUiThread { startActivity(Intent(this, RearActivity::class.java).putExtra("move", true).putExtra("rear", id)) }
            } else if (stop) { Thread.sleep(900); try { Sh.exec("am force-stop ${Sh.XIAOMI}") } catch (e: Throwable) {} }
        }.start()
    }

    private fun toast(s: String?) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
