package com.example.rearytm

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

/** Işık hüzmeleri + parıltı efektli arka ekran arayüzü. Her şey tek View'da çizilir. */
class RearView(ctx: Context) : View(ctx) {
    class Info(val title: String, val artist: String, val art: Bitmap?, val dur: Long, val pos: Long,
               val playing: Boolean, val liked: Boolean, val stamp: Long = SystemClock.elapsedRealtime())

    var info: Info? = null
    var onPrev: () -> Unit = {}; var onPlay: () -> Unit = {}; var onNext: () -> Unit = {}
    var onLike: () -> Unit = {}; var onLikeLong: () -> Unit = {}; var onSwitch: () -> Unit = {}

    private var accent = 0xFF7C5CFF.toInt(); private var accent2 = 0xFF22D3EE.toInt()
    private var msg: String? = null; private var msgUntil = 0L
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val titleP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) }
    private val artistP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create("sans-serif", Typeface.NORMAL) }
    private val path = Path(); private val artRect = RectF(); private val src = Rect(); private val sweepM = Matrix()
    private var t = 0f; private var energy = 0.2f; private var last = 0L
    private var tx0 = 0f; private var tx1 = 0f; private var titleY = 0f; private var artistY = 0f
    private var progY = 0f; private var ctrlY = 0f; private var rs = 0f; private var prs = 0f; private var ts = 0f
    private var cxPrev = 0f; private var cxPlay = 0f; private var cxNext = 0f; private var hx = 0f; private var hy = 0f; private var hr = 0f
    private var beamLen = 0f; private var pressed = 0; private var downT = 0L
    private var beam1: Shader? = null; private var beam2: Shader? = null; private var vign: Shader? = null
    private var glow: Shader? = null; private var sweep: SweepGradient? = null; private var prog: Shader? = null
    private var head: Shader? = null; private var btnGlow: Shader? = null; private var heartGlow: Shader? = null

    private fun a(c: Int, al: Int) = (c and 0x00FFFFFF) or (al.coerceIn(0, 255) shl 24)

    fun setAccent(c: Int) {
        accent = c
        val hsv = FloatArray(3); Color.colorToHSV(c, hsv); hsv[0] = (hsv[0] + 50f) % 360f
        accent2 = Color.HSVToColor(hsv); rebuild()
    }
    fun flash(m: String) { msg = m; msgUntil = SystemClock.elapsedRealtime() + 3000 }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { layoutAll(w.toFloat(), h.toFloat()); rebuild() }

    private fun layoutAll(w: Float, h: Float) {
        if (w >= h) {
            val pad = h * 0.07f; val s = h * 0.58f
            artRect.set(pad, pad, pad + s, pad + s)
            tx0 = pad * 2 + s; tx1 = w - pad; ts = h * 0.082f
            titleY = pad + s * 0.30f; artistY = pad + s * 0.53f; progY = pad + s * 0.84f
            rs = h * 0.062f; ctrlY = h - pad - rs * 1.4f
        } else {
            val pad = w * 0.08f; val s = min(w - 2 * pad, h * 0.40f)
            artRect.set((w - s) / 2, pad * 1.4f, (w + s) / 2, pad * 1.4f + s)
            tx0 = pad; tx1 = w - pad; ts = w * 0.062f
            titleY = artRect.bottom + ts * 2.2f; artistY = titleY + ts * 1.3f; progY = artistY + ts * 1.8f
            rs = w * 0.085f; ctrlY = progY + (h - progY) * 0.55f
        }
        prs = rs * 1.4f; cxPlay = w / 2; cxPrev = w / 2 - prs * 2.4f; cxNext = w / 2 + prs * 2.4f
        hr = ts * 0.62f; hx = tx1 - hr; hy = titleY - ts * 0.3f
        titleP.textSize = ts; artistP.textSize = ts * 0.72f
    }

    private fun rebuild() {
        val w = width.toFloat(); val h = height.toFloat(); if (w <= 0f) return
        beamLen = hypot(w, h) * 1.25f
        fun lg(c: Int) = LinearGradient(0f, 0f, 0f, beamLen, intArrayOf(a(c, 170), a(c, 0)), null, Shader.TileMode.CLAMP)
        beam1 = lg(accent); beam2 = lg(accent2)
        vign = LinearGradient(0f, h * 0.3f, 0f, h, 0x00000000, 0xE8000000.toInt(), Shader.TileMode.CLAMP)
        val s = artRect.width()
        glow = RadialGradient(artRect.centerX(), artRect.centerY(), s * 1.15f, intArrayOf(a(accent, 190), a(accent2, 60), 0), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        sweep = SweepGradient(artRect.centerX(), artRect.centerY(), intArrayOf(accent, accent2, a(accent, 0), accent), null)
        prog = LinearGradient(tx0, 0f, tx1, 0f, accent, accent2, Shader.TileMode.CLAMP)
        head = RadialGradient(0f, 0f, ts * 0.9f, intArrayOf(a(accent2, 230), 0), null, Shader.TileMode.CLAMP)
        btnGlow = RadialGradient(0f, 0f, prs * 2.1f, intArrayOf(a(accent, 255), a(accent2, 110), 0), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
        heartGlow = RadialGradient(0f, 0f, hr * 2.4f, intArrayOf(0xB0FF4D79.toInt(), 0), null, Shader.TileMode.CLAMP)
    }

    private fun reset() { p.shader = null; p.style = Paint.Style.FILL; p.blendMode = BlendMode.SRC_OVER; p.color = Color.WHITE; p.strokeCap = Paint.Cap.BUTT }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val now = SystemClock.elapsedRealtime()
        val dt = if (last == 0L) 0.016f else ((now - last) / 1000f).coerceAtMost(0.05f); last = now
        val inf = info
        val target = when { inf == null -> 0.22f; inf.playing -> 1f; else -> 0.4f }
        energy += (target - energy) * min(1f, dt * 2.5f)
        t += dt * (0.35f + 0.9f * energy)

        c.drawColor(0xFF05060B.toInt())
        beams(c, w)
        reset(); p.shader = vign; c.drawRect(0f, 0f, w, h, p); p.shader = null
        if (inf == null) idle(c, w, h) else { art(c, inf); texts(c, inf, now); progress(c, inf, now); controls(c, inf) }
        postInvalidateOnAnimation()
    }

    private fun beams(c: Canvas, w: Float) {
        val s1 = beam1 ?: return; val s2 = beam2 ?: return
        val sx = w / 2f + sin(t * 0.5f) * w * 0.18f; val sy = -height * 0.12f
        for (i in 0 until 6) {
            val ang = (i - 2.5f) * 13f + sin(t * (0.6f + i * 0.13f) + i * 1.7f) * (9f + i)
            val half = beamLen * (0.045f + 0.012f * ((i * 7) % 3))
            c.save(); c.translate(sx, sy); c.rotate(ang)
            reset(); p.shader = if (i % 2 == 0) s1 else s2; p.blendMode = BlendMode.PLUS
            for (k in 0 until 3) {
                val f = 1f - k * 0.28f
                path.reset(); path.moveTo(0f, 0f); path.lineTo(-half * f, beamLen); path.lineTo(half * f, beamLen); path.close()
                p.alpha = (36 + 70 * energy).toInt(); c.drawPath(path, p)
            }
            c.restore()
        }
        reset()
    }

    private fun art(c: Canvas, i: Info) {
        val s = artRect.width(); val rr = s * 0.14f
        c.save(); c.translate(0f, 0f)
        reset(); p.shader = glow; p.blendMode = BlendMode.PLUS
        p.alpha = (70 + 170 * energy * (0.85f + 0.15f * sin(t * 2f))).toInt().coerceIn(0, 255)
        c.drawCircle(artRect.centerX(), artRect.centerY(), s * 1.15f, p)
        reset()
        c.save(); path.reset(); path.addRoundRect(artRect, rr, rr, Path.Direction.CW); c.clipPath(path)
        val b = i.art
        if (b != null) {
            val m = min(b.width, b.height); src.set((b.width - m) / 2, (b.height - m) / 2, (b.width + m) / 2, (b.height + m) / 2)
            c.drawBitmap(b, src, artRect, bp)
        } else {
            p.shader = LinearGradient(artRect.left, artRect.top, artRect.right, artRect.bottom, accent, accent2, Shader.TileMode.CLAMP)
            c.drawRect(artRect, p); p.shader = null
            p.color = 0xCCFFFFFF.toInt(); p.textSize = s * 0.5f; p.textAlign = Paint.Align.CENTER
            c.drawText("♪", artRect.centerX(), artRect.centerY() + s * 0.17f, p); p.textAlign = Paint.Align.LEFT
        }
        c.restore()
        reset()
        sweepM.setRotate(t * 50f, artRect.centerX(), artRect.centerY()); sweep?.setLocalMatrix(sweepM)
        p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.018f; p.shader = sweep
        p.alpha = (110 + 145 * energy).toInt(); c.drawRoundRect(artRect, rr, rr, p)
        reset(); c.restore()
    }

    private fun texts(c: Canvas, i: Info, now: Long) {
        val tw = tx1 - tx0 - hr * 2.8f
        c.drawText(TextUtils.ellipsize(i.title.ifBlank { "—" }, titleP, tw, TextUtils.TruncateAt.END).toString(), tx0, titleY, titleP)
        val flashing = msg != null && now < msgUntil
        artistP.color = if (flashing) accent2 else 0xB3FFFFFF.toInt()
        val sub = if (flashing) msg!! else i.artist
        c.drawText(TextUtils.ellipsize(sub, artistP, tx1 - tx0, TextUtils.TruncateAt.END).toString(), tx0, artistY, artistP)
    }

    private fun progress(c: Canvas, i: Info, now: Long) {
        val pos = (i.pos + if (i.playing) now - i.stamp else 0L).coerceIn(0L, max(i.dur, 1L))
        val frac = if (i.dur > 0) pos.toFloat() / i.dur else 0f
        val bw = ts * 0.13f; val x = tx0 + (tx1 - tx0) * frac
        reset(); p.style = Paint.Style.STROKE; p.strokeWidth = bw; p.strokeCap = Paint.Cap.ROUND
        p.color = 0x33FFFFFF; c.drawLine(tx0, progY, tx1, progY, p)
        p.shader = prog; c.drawLine(tx0, progY, max(x, tx0 + 0.1f), progY, p)
        reset(); c.save(); c.translate(x, progY)
        p.shader = head; p.blendMode = BlendMode.PLUS; c.drawCircle(0f, 0f, ts * 0.9f, p)
        reset(); c.drawCircle(0f, 0f, bw * 0.95f, p); c.restore()
    }

    private fun controls(c: Canvas, i: Info) {
        c.save(); c.translate(cxPlay, ctrlY); val sc = if (pressed == 2) 0.92f else 1f; c.scale(sc, sc)
        reset(); p.shader = btnGlow; p.blendMode = BlendMode.PLUS
        p.alpha = (60 + 150 * energy * (0.85f + 0.15f * sin(t * 3f))).toInt().coerceIn(0, 255)
        c.drawCircle(0f, 0f, prs * 2.1f, p)
        reset(); p.color = 0xF5FFFFFF.toInt(); c.drawCircle(0f, 0f, prs, p)
        p.color = 0xFF0A0B12.toInt(); val u = prs * 0.42f
        if (i.playing) {
            c.drawRoundRect(-u * 0.75f, -u, -u * 0.2f, u, u * 0.15f, u * 0.15f, p)
            c.drawRoundRect(u * 0.2f, -u, u * 0.75f, u, u * 0.15f, u * 0.15f, p)
        } else {
            path.reset(); path.moveTo(-u * 0.6f, -u * 0.95f); path.lineTo(-u * 0.6f, u * 0.95f); path.lineTo(u * 0.95f, 0f); path.close(); c.drawPath(path, p)
        }
        c.restore()
        side(c, cxPrev, 1, false); side(c, cxNext, 3, true)

        c.save(); c.translate(hx, hy); val hs = if (pressed == 4) 0.85f else 1f; c.scale(hs, hs)
        if (i.liked) {
            reset(); p.shader = heartGlow; p.blendMode = BlendMode.PLUS; p.alpha = (150 + 90 * sin(t * 4f)).toInt().coerceIn(0, 255)
            c.drawCircle(0f, 0f, hr * 2.4f, p)
        }
        val k = hr
        path.reset(); path.moveTo(0f, k * 0.9f)
        path.cubicTo(-k * 1.9f, -k * 0.2f, -k * 0.8f, -k * 1.3f, 0f, -k * 0.45f)
        path.cubicTo(k * 0.8f, -k * 1.3f, k * 1.9f, -k * 0.2f, 0f, k * 0.9f); path.close()
        reset()
        if (i.liked) p.color = 0xFFFF4D79.toInt() else { p.style = Paint.Style.STROKE; p.strokeWidth = k * 0.16f; p.strokeJoin = Paint.Join.ROUND; p.color = 0xB3FFFFFF.toInt() }
        c.drawPath(path, p); reset(); c.restore()
    }

    private fun side(c: Canvas, cx: Float, id: Int, flip: Boolean) {
        c.save(); c.translate(cx, ctrlY); val s = if (pressed == id) 0.86f else 1f; c.scale(if (flip) -s else s, s)
        reset(); p.color = 0xE6FFFFFF.toInt(); val u = rs * 0.62f
        c.drawRoundRect(-u * 1.25f, -u * 0.85f, -u * 0.85f, u * 0.85f, u * 0.15f, u * 0.15f, p)
        path.reset(); path.moveTo(u * 1.1f, -u * 0.95f); path.lineTo(u * 1.1f, u * 0.95f); path.lineTo(-u * 0.65f, 0f); path.close()
        c.drawPath(path, p); c.restore()
    }

    private fun idle(c: Canvas, w: Float, h: Float) {
        titleP.textAlign = Paint.Align.CENTER; artistP.textAlign = Paint.Align.CENTER
        artistP.color = 0x99FFFFFF.toInt()
        c.drawText("Müzik bekleniyor", w / 2, h * 0.50f, titleP)
        c.drawText("Seçili uygulamada bir şey çal", w / 2, h * 0.50f + ts * 1.3f, artistP)
        titleP.textAlign = Paint.Align.LEFT; artistP.textAlign = Paint.Align.LEFT
    }

    private fun hit(x: Float, y: Float): Int {
        fun near(cx: Float, cy: Float, r: Float) = hypot(x - cx, y - cy) <= r
        return when {
            near(cxPlay, ctrlY, prs * 1.5f) -> 2
            near(cxPrev, ctrlY, rs * 1.8f) -> 1
            near(cxNext, ctrlY, rs * 1.8f) -> 3
            near(hx, hy, hr * 2f) -> 4
            else -> 0
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { pressed = hit(e.x, e.y); downT = e.eventTime }
            MotionEvent.ACTION_UP -> {
                val h = hit(e.x, e.y)
                if (h != 0 && h == pressed) when (h) {
                    1 -> onPrev(); 2 -> onPlay(); 3 -> onNext()
                    4 -> if (e.eventTime - downT > 600) onLikeLong() else onLike()
                } else if (h == 0 && e.x in tx0..tx1 && e.y in (titleY - ts)..(artistY + ts)) onSwitch()
                pressed = 0
            }
            MotionEvent.ACTION_CANCEL -> pressed = 0
        }
        return true
    }
}
