package com.example.rearytm

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Color
import android.media.MediaMetadata
import android.media.Rating
import android.media.session.PlaybackState
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.View
import android.view.WindowManager

class RearActivity : Activity() {
    companion object { var inst: RearActivity? = null }
    private val h = Handler(Looper.getMainLooper())
    private lateinit var v: RearView
    private var idx = 0
    private var lastKey = ""
    private var lastArt: Bitmap? = null
    private var localLiked = false
    private var curLiked = false

    private fun cur() = Media.sessions(this).let { if (it.isEmpty()) null else it[idx % it.size] }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        inst = this
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        v = RearView(this)
        v.onPrev = { cur()?.transportControls?.skipToPrevious() }
        v.onNext = { cur()?.transportControls?.skipToNext() }
        v.onPlay = { cur()?.let { if (it.playbackState?.state == PlaybackState.STATE_PLAYING) it.transportControls.pause() else it.transportControls.play() } }
        v.onSwitch = { idx++; lastKey = ""; v.flash("Kaynak değişti") }
        v.onLike = { toggleLike() }
        v.onLikeLong = { v.flash(actionsText()) }
        setContentView(v)

        // Doğrudan açılma engellendiyse: ön ekranda başlayıp Shizuku ile arka ekrana taşınır.
        if (intent.getBooleanExtra("move", false) && windowManager.defaultDisplay.displayId == Display.DEFAULT_DISPLAY) {
            val rear = intent.getIntExtra("rear", 1); val tid = taskId; val stop = Media.stopXiaomi(this)
            Thread {
                Thread.sleep(700)
                val r = try { Sh.exec("am display move-stack $tid $rear") } catch (e: Throwable) { e.message ?: "" }
                if (stop) { Thread.sleep(900); try { Sh.exec("am force-stop ${Sh.XIAOMI}") } catch (e: Throwable) {} }
                if (r.isNotBlank()) h.post { v.flash(r.take(60)) }
            }.start()
        }
    }

    private fun toggleLike() {
        val c = cur() ?: return
        val act = Media.likeAction(c.playbackState)
        when {
            act != null -> { c.transportControls.sendCustomAction(act, null); localLiked = !curLiked }
            c.ratingType == Rating.RATING_THUMB_UP_DOWN -> { c.transportControls.setRating(Rating.newThumbRating(!curLiked)); localLiked = !curLiked }
            c.ratingType == Rating.RATING_HEART -> { c.transportControls.setRating(Rating.newHeartRating(!curLiked)); localLiked = !curLiked }
            else -> v.flash("Bu uygulama beğeniyi dışarı açmıyor")
        }
    }

    private fun actionsText(): String {
        val c = cur() ?: return "Oturum yok"
        val names = c.playbackState?.customActions?.joinToString { it.name } ?: ""
        return "Eylemler: ${names.ifBlank { "yok" }} · puan=${c.ratingType}"
    }

    private fun accentOf(b: Bitmap?): Int {
        val def = 0xFF7C5CFF.toInt()
        if (b == null) return def
        return try {
            val s = Bitmap.createScaledBitmap(b.copy(Bitmap.Config.ARGB_8888, false), 8, 8, true)
            val hsv = FloatArray(3); var best = def; var bs = -1f
            for (x in 0 until 8) for (y in 0 until 8) {
                val px = s.getPixel(x, y); Color.colorToHSV(px, hsv)
                val sc = hsv[1] * hsv[2]; if (sc > bs) { bs = sc; best = px }
            }
            Color.colorToHSV(best, hsv); hsv[1] = maxOf(hsv[1], 0.55f); hsv[2] = 1f
            Color.HSVToColor(hsv)
        } catch (e: Throwable) { def }
    }

    private fun update() {
        val c = cur()
        if (c == null) { v.info = null; return }
        val md = c.metadata; val st = c.playbackState
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        val art = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val key = "$title|$artist|${c.packageName}"
        if (key != lastKey) { lastKey = key; localLiked = false }
        if (art !== lastArt || key != lastKey) { lastArt = art; v.setAccent(accentOf(art)) }
        val rating = md?.getRating(MediaMetadata.METADATA_KEY_USER_RATING)
        val act = Media.likeAction(st)
        val known: Boolean? = when {
            rating != null && rating.isRated -> rating.isThumbUp || rating.hasHeart()
            act != null && Media.UNLIKE.containsMatchIn(Media.txt(act)) -> true
            else -> null
        }
        curLiked = known ?: localLiked
        val playing = st?.state == PlaybackState.STATE_PLAYING
        val pos = if (st == null) 0L else if (playing)
            st.position + ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong() else st.position
        v.info = RearView.Info(title, artist, art, md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L, pos, playing, curLiked)
    }

    private val tick = object : Runnable { override fun run() { update(); h.postDelayed(this, 250) } }
    override fun onResume() { super.onResume(); tick.run() }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
    override fun onDestroy() { super.onDestroy(); if (inst === this) inst = null }
}
