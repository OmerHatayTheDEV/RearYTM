package com.example.rearytm

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object Sh {
    const val CODE = 100
    const val PKG = "com.example.rearytm"
    const val COMP = "$PKG/$PKG.MediaListener"
    const val XIAOMI = "com.xiaomi.subscreencenter"

    fun available() = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
    fun granted() = available() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED

    fun exec(cmd: String): String {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
        p.waitFor()
        return out.trim()
    }

    // Bildirim dinleyiciyi açar, "kısıtlı ayar" engelini kaldırır, pil muafiyeti verir.
    fun setup(): String = exec("""
        appops set %P ACCESS_RESTRICTED_SETTINGS allow
        cmd notification allow_listener %C
        cur=§(settings get secure enabled_notification_listeners)
        case "§cur" in *%P*) ;; *)
          if [ -z "§cur" ] || [ "§cur" = null ]; then n=%C; else n="§cur:%C"; fi
          settings put secure enabled_notification_listeners "§n";;
        esac
        dumpsys deviceidle whitelist +%P
        cmd appops set %P RUN_IN_BACKGROUND allow
    """.trimIndent().replace("%P", PKG).replace("%C", COMP).replace('§', '$'))
}
